package edu.ualr.jxcarlat.login

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.channel_list_activity.*
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread
import java.lang.Exception


class ChannelListActivity : AppCompatActivity() {

    //If we hit this activity our login was successful and we grab the key from the previous login
    //activity to take with us. We set our variable theKey to our key being held in our
    //Shared Preferences KEY_AUTHORIZATION.
    lateinit var theKey: String
    lateinit var client: OkHttpClient
    lateinit var linearLayoutNames: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.channel_list_activity)

        theKey = intent.getStringExtra(KEY_AUTHORIZATION)
        Log.d("MPK_UTILITY", theKey)
    }

    override fun onResume() {
        super.onResume()

        linearLayoutNames = findViewById(R.id.linearLayout2)
        linearLayoutNames.removeAllViews()
        //We're going to have to use an authorization header from here on out.
        //In order to keep going throughout the app we need to get the value of theKey and combine
        //it with the string "Token[Space]" in order to communicate with the REST API
        val request: Request = Request.Builder()
                .url("http://messenger.mattkennett.com/api/v1/channels/")
                .header("Authorization", "Token " + theKey)
                .build()

        doAsync {
            var response: Response? = null
            client = OkHttpClient()

            try {
                response = client.newCall(request).execute()
            } catch (e: Exception) {
                Log.d("MPK_UTILITY", "Network Error")
            }

            if (response != null) {
                val responseBody: String = response.body()!!.string()

                val gson = Gson()
                Log.d("MPK_UTILITY", "I'm here first")
                //Instead of relying on Array<String>? from GithubUser let's use the
                //new Data Class ChatChannel and simply initialize channelId as a List element to
                //ChatChannel so that when we grab the Json object we're not dealing with messy
                //string arrays.
                val channelId: List<ChatChannel>
                        = gson.fromJson(responseBody,
                        object : TypeToken<List<ChatChannel>>() {}.type)
                Log.d("MPK_UTILITY", "I'm here")
                //Log.d("MPK_UTILITY", channelId.name.text.toString())
                uiThread {
                    //If we successfully retrieve a name then we can start priming our linear layout
                    //with buttons containing pathways to chat rooms. We also have to be sure to grab
                    //the pk value and take it with us into ChatChannelActivity since it will be important
                    //later.
                        val intent = Intent(this@ChannelListActivity, ChatChannelActivity::class.java)
                    if(channelId[0].name != null) {
                        for (names in channelId) {
                            val newButton = Button(this@ChannelListActivity)
                            newButton.text = names.name
                            newButton.setOnClickListener {
                                intent.putExtra(PK_ID, names.pk)
                                Log.d("MPK_UTILITY", "The pk value is: " + PK_ID)
                                intent.putExtra(KEY_AUTHORIZATION, theKey)
                                Log.d("MPK_UTILITY", "The key value is: " + KEY_AUTHORIZATION)
                                Log.d("MPK_UTILITY", "The pk value is now: " + PK_ID)
                                startActivity(intent)
                                Log.d("MPK_UTILITY", "I've been pushed")
                            }
                            linearLayoutNames.addView(newButton)
                        }
                    }
                    //If we didn't retrieve a name then we've gotten an error detail, we can print
                    //the error message out as a view to the linearLayout.
                    else
                    {
                        val linearLayoutMessage: LinearLayout = findViewById(R.id.linearLayout2)
                        val newTextView2 = TextView(this@ChannelListActivity)
                        var newTextViewString: String? = ""
                        newTextViewString = channelId[0].detail
                        newTextView2.text = newTextViewString
                        linearLayoutMessage.addView(newTextView2)
                    }
                }
            }
        }
    }
}



