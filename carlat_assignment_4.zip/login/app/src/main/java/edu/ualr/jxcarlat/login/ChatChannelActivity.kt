package edu.ualr.jxcarlat.login

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import okhttp3.*
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread
import java.lang.Exception

class ChatChannelActivity : AppCompatActivity() {
    lateinit var theKey: String
    lateinit var pkValue: String
    lateinit var client: OkHttpClient
    lateinit var linearLayoutNames: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_channel)
        //Bring our pk value and our authorization key in order to access the chat room.
        pkValue = intent.getStringExtra(PK_ID)
        theKey = intent.getStringExtra(KEY_AUTHORIZATION)
        Log.d("MPK_UTILITY", theKey)

    }

    override fun onResume() {
        super.onResume()
        //We build our request to the server with our pkValue and key authorization values.
        val request: Request = Request.Builder()
                .url("http://messenger.mattkennett.com/api/v1/channel-messages/" + pkValue + "/")
                .header("Authorization", "Token " + theKey)
                .build()

        doAsync {
            var response: Response? = null
            client = OkHttpClient()

            try {
                response = client.newCall(request).execute()
            } catch (e: Exception) {
                Log.d("MPK_UTILITY", "Network Error")
            }

            if (response != null) {
                val responseBody: String = response.body()!!.string()

                val gson = Gson()
                Log.d("MPK_UTILITY", "I'm about to gson")
                val channelId: List<ChatChannel> = gson.fromJson(responseBody,
                        object : TypeToken<List<ChatChannel>>() {}.type)
                Log.d("MPK_UTILITY", "I'm here")
                //If we succeed in getting a response then print all of the previous messages from
                //previous users including channelId, timestamp, uniqueId of user, and username
                //to our bottom linearLayout within our XML file. We have an upper linearLayout
                //but we'll discuss its function later in the program.
                uiThread {
                    if (channelId[0].channel != null) {
                        val linearLayoutMessage: LinearLayout = findViewById(R.id.linearLayout)
                        var newTextViewString: String? = ""
                        for (users in channelId) {
                            val newTextView = TextView(this@ChatChannelActivity)
                            newTextViewString = users.channel + users.message + users.timestamp + users.user?.pk + users.user?.username
                            newTextView.text = newTextViewString
                            linearLayoutMessage.addView(newTextView)
                        }
                        //So we have a button and an editText within our XML file. These will serve
                        //as the means to send messages to the chat rooms. When we click our sendButton
                        //we'll send a message that the user has typed
                        // within the editText space, to the corresponding channel
                        //they're currently in.
                        val sendButton: Button = findViewById(R.id.button5)
                        sendButton.setOnClickListener {
                            //We must build a form so that the message gets sent to the chatroom.
                            //Using our authorization key with "Token[Space]" we communicate with
                            //the messages endpoint of the API and send a message to the corresponding
                            //channel.
                            val myUrl = "http://messenger.mattkennett.com/api/v1/messages/"
                            val sendMessage: EditText = findViewById(R.id.editText6)
                            val formBody: RequestBody = FormBody.Builder()
                                    .add("channel", channelId[0].channel)
                                    .add("message", sendMessage.text.toString())
                                    .build()
                            val request: Request = Request.Builder()
                                    .url(myUrl)
                                    .header("Authorization", "Token " + theKey)
                                    .post(formBody)
                                    .build()
                            //If we get this far then the message was successfully sent. We print
                            //a notification to our user in our upper linearLayout informing them
                            //of the success.

                            val linearLayoutMessage2: LinearLayout = findViewById(R.id.linearLayout2)
                            linearLayoutMessage2.removeAllViews()
                            val newTextView2 = TextView(this@ChatChannelActivity)
                            newTextViewString = "Message sent!"
                            newTextView2.text = newTextViewString
                            linearLayoutMessage2.addView(newTextView2)
                            //doAsync will work a little differently here. While we were used to
                            //grabbing Json objects with information and using them accordingly
                            //we're hoping we don't get a Json object this time around. The
                            //reason being if we get a message successfully sent to the channel
                            //then we should return nothing. Otherwise the Json object we do receive
                            //will be an error message or an app breaking large HTML page we don't
                            //want to parse.
                            doAsync {
                                var response2: Response? = null
                                client = OkHttpClient()
                                Log.d("MPK_UTILITY", "2nd response")
                                try {
                                    response2 = client.newCall(request).execute()
                                } catch (e: Exception) {
                                    Log.d("MPK_UTILITY", "Network Error")
                                }

                                if (response2 != null) {
                                    val responseBody: String = response2.body()!!.string()

                                    val gson = Gson()
                                    Log.d("MPK_UTILITY", "about to gson")
                                    val messenger: List<ChatChannel>
                                            = gson.fromJson(responseBody,
                                            object : TypeToken<List<ChatChannel>>() {}.type)
                                    Log.d("MPK_UTILITY", "I'm finally here")
                                    //If we did get a gson object the only information on it will be
                                    //an error detail. We print that message to the upper linearLayout
                                    //within our app. No need for conditionals here
                                    uiThread {
                                        val linearLayoutMessage2: LinearLayout = findViewById(R.id.linearLayout2)
                                            val newTextView3 = TextView(this@ChatChannelActivity)
                                            newTextViewString = messenger[0].detail
                                            newTextView3.text = newTextViewString
                                            linearLayoutMessage2.addView(newTextView3)
                                    }
                                }
                            }

                        }


                    }
                }
            }
        }
            }
        }
